#!/usr/bin/env python3
import json
import re
import sys
import time
import numpy as np

FANCY = {"\u2019": "'", "\u2018": "'", "\u201c": '"', "\u201d": '"',
         "\u2013": "-", "\u2014": "-", "\u2026": "..."}
INPUT_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789 .,!?'-:;()/&\""
ALLOWED_CHARS = set(INPUT_CHARS)
MAX_INPUT_CHARS = 200


def normalize_input(text):
    """Lowercase, plain ASCII, allowed characters only, single spaces."""
    for k, v in FANCY.items():
        text = text.replace(k, v)
    text = text.lower()
    text = "".join(ch if ch in ALLOWED_CHARS else " " for ch in text)
    return re.sub(r"\s+", " ", text).strip()


SPECIALS = ["<pad>", "<bos>", "<sep>", "<eos>", "<unk>"]
OUTPUT_WORDS = ["FWD", "BACK", "LEFT", "RIGHT", "UNTIL", "SEARCH", "WATCH", "STOP",
                "UNKNOWN", "bottle", "cup", "chair", "person"]
VOCAB = SPECIALS + list(INPUT_CHARS) + OUTPUT_WORDS
TOK2ID = {t: i for i, t in enumerate(VOCAB)}
PAD, BOS, SEP, EOS, UNK = [TOK2ID[t] for t in SPECIALS]
OUTPUT_SYMBOLS = OUTPUT_WORDS + list("0123456789") + [".", "s", ";"]
OUTPUT_IDS = sorted(TOK2ID[t] for t in OUTPUT_SYMBOLS) + [EOS]
NUMBER_PARTS = set("0123456789.s")

OUT_TOKEN_RE = re.compile(r"FWD|BACK|LEFT|RIGHT|UNTIL|SEARCH|WATCH|STOP|UNKNOWN|"
                          r"bottle|cup|chair|person|[0-9]|\.|s|;")


_OBJ = "bottle|cup|chair|person"
_STEP_RE = re.compile(r"^(?:(?:FWD|BACK|LEFT|RIGHT) (?:\d+(?:\.\d+)?s|\d+)|FWD UNTIL (?:%s)|SEARCH (?:%s))$"
                      % (_OBJ, _OBJ))
_WATCH_RE = re.compile(r"^WATCH (?:%s)$" % _OBJ)


def valid_output(o):
    if o in ("STOP", "UNKNOWN"):
        return True
    parts = o.split("; ")
    if _WATCH_RE.match(parts[0]):
        parts = parts[1:]
    return 1 <= len(parts) <= 4 and all(_STEP_RE.match(p) for p in parts)


def encode_input(text):
    text = normalize_input(text)
    return [BOS] + [TOK2ID.get(ch, UNK) for ch in text] + [SEP]


def encode_output(label):
    toks = OUT_TOKEN_RE.findall(label)
    if decode_tokens(toks) != label:
        raise ValueError("label does not round-trip through the tokenizer: %r" % label)
    return [TOK2ID[t] for t in toks]


def decode_tokens(toks):
    pieces = []
    for t in toks:
        if t in NUMBER_PARTS and pieces and pieces[-1][0].isdigit() and t != ";":
            pieces[-1] += t          # continue a number like 1.5s
        else:
            pieces.append(t)
    return " ".join(pieces).replace(" ;", ";")


def decode_output(ids):
    return decode_tokens([VOCAB[i] for i in ids])


# Model
def _layer_norm(x, w, b, eps=1e-5):
    mu = x.mean(axis=-1, keepdims=True)
    var = ((x - mu) ** 2).mean(axis=-1, keepdims=True)
    return (x - mu) / np.sqrt(var + eps) * w + b


def _gelu_tanh(x):
    return 0.5 * x * (1.0 + np.tanh(np.float32(0.7978845608028654) * (x + np.float32(0.044715) * x ** 3)))


class TinyLMNumpy(object):
    def __init__(self, weights_path="tiny_lm_weights.npz", config_path="tiny_lm_config.json"):
        with open(config_path) as f:
            cfg = json.load(f)
        if cfg["vocab"] != VOCAB:
            raise ValueError("vocabulary in config does not match this file: use the matching "
                             "tiny_lm_numpy.py from the same training run")
        self.d = cfg["d_model"]
        self.n_layer = cfg["n_layer"]
        self.n_head = cfg["n_head"]
        self.hd = self.d // self.n_head
        self.max_len = cfg["max_len"]
        self.max_new = cfg.get("max_new_tokens", 48)
        w = np.load(weights_path, allow_pickle=False)
        g = lambda k: np.ascontiguousarray(w[k].astype(np.float32))
        self.tok = g("tok_emb.weight")                 # (V, d), also the output layer
        self.pos = g("pos_emb.weight")                 # (max_len, d)
        self.layers = []
        for i in range(self.n_layer):
            p = "blocks.%d." % i
            self.layers.append({
                "ln1_w": g(p + "ln1.weight"), "ln1_b": g(p + "ln1.bias"),
                "qkv_w": np.ascontiguousarray(g(p + "attn.qkv.weight").T), "qkv_b": g(p + "attn.qkv.bias"),
                "proj_w": np.ascontiguousarray(g(p + "attn.proj.weight").T), "proj_b": g(p + "attn.proj.bias"),
                "ln2_w": g(p + "ln2.weight"), "ln2_b": g(p + "ln2.bias"),
                "fc1_w": np.ascontiguousarray(g(p + "mlp.fc1.weight").T), "fc1_b": g(p + "mlp.fc1.bias"),
                "fc2_w": np.ascontiguousarray(g(p + "mlp.fc2.weight").T), "fc2_b": g(p + "mlp.fc2.bias"),
            })
        self.lnf_w, self.lnf_b = g("ln_f.weight"), g("ln_f.bias")
        self.scale = np.float32(1.0 / np.sqrt(self.hd))
        self.out_mask = np.full(len(VOCAB), -np.inf, dtype=np.float32)
        self.out_mask[OUTPUT_IDS] = 0.0

    def _forward(self, ids, cache):
        """Run new token ids through the model, extending the cache. Returns last-position logits."""
        n, past = len(ids), cache["len"]
        if past + n > self.max_len:
            raise ValueError("sequence longer than max_len")
        x = self.tok[ids] + self.pos[past:past + n]                       # (n, d)
        mask = None
        if n > 1:
            mask = np.triu(np.ones((n, past + n), dtype=bool), k=past + 1)
        for i, L in enumerate(self.layers):
            h = _layer_norm(x, L["ln1_w"], L["ln1_b"])
            qkv = h @ L["qkv_w"] + L["qkv_b"]                              # (n, 3d)
            q, k, v = [a.reshape(n, self.n_head, self.hd).transpose(1, 0, 2)
                       for a in (qkv[:, :self.d], qkv[:, self.d:2 * self.d], qkv[:, 2 * self.d:])]
            if past:
                k = np.concatenate([cache["k"][i], k], axis=1)
                v = np.concatenate([cache["v"][i], v], axis=1)
            if i < len(cache["k"]):
                cache["k"][i], cache["v"][i] = k, v
            else:
                cache["k"].append(k)
                cache["v"].append(v)
            att = (q @ k.transpose(0, 2, 1)) * self.scale                  # (H, n, past+n)
            if mask is not None:
                att = np.where(mask[None, :, :], -np.inf, att)
            att = att - att.max(axis=-1, keepdims=True)
            att = np.exp(att)
            att /= att.sum(axis=-1, keepdims=True)
            y = (att @ v).transpose(1, 0, 2).reshape(n, self.d)
            x = x + y @ L["proj_w"] + L["proj_b"]
            h = _layer_norm(x, L["ln2_w"], L["ln2_b"])
            x = x + _gelu_tanh(h @ L["fc1_w"] + L["fc1_b"]) @ L["fc2_w"] + L["fc2_b"]
        cache["len"] = past + n
        last = _layer_norm(x[-1], self.lnf_w, self.lnf_b)
        return last @ self.tok.T                                            # (V,)

    def generate_ids(self, prompt_ids):
        cache = {"len": 0, "k": [], "v": []}
        logits = self._forward(prompt_ids, cache)
        out = []
        for _ in range(self.max_new):
            t = int(np.argmax(logits + self.out_mask))
            if t == EOS:
                break
            out.append(t)
            if cache["len"] + 1 > self.max_len:
                break
            logits = self._forward([t], cache)
        return out

    def predict(self, text):
        t0 = time.perf_counter()
        norm = normalize_input(text)
        info = {"normalized": norm, "raw": "", "valid": True}
        if not norm or len(norm) > MAX_INPUT_CHARS:
            info["valid"] = False
            info["ms"] = (time.perf_counter() - t0) * 1000.0
            return "UNKNOWN", info
        raw = decode_output(self.generate_ids(encode_input(norm)))
        info["raw"] = raw
        info["valid"] = valid_output(raw)
        info["ms"] = (time.perf_counter() - t0) * 1000.0
        return (raw if info["valid"] else "UNKNOWN"), info


def _main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default="tiny_lm_weights.npz")
    ap.add_argument("--config", default="tiny_lm_config.json")
    ap.add_argument("--bench", action="store_true", help="time 20 typical commands")
    a = ap.parse_args()
    lm = TinyLMNumpy(a.weights, a.config)
    if a.bench:
        cmds = ["go forward 5 sec", "turn left", "go forward until you see a bottle",
                "go forward 5 sec then turn left 3 sec and stop if you see a bottle",
                "back up a little", "find the cup", "stop", "make me coffee",
                "drive 2 meters, turn right 90 degrees, then search for a bottle",
                "turn around"] * 2
        lm.predict("warm up")
        times = [lm.predict(c)[1]["ms"] for c in cmds]
        print("average %.1f ms, slowest %.1f ms over %d commands" % (sum(times) / len(times), max(times), len(times)))
        return
    print("Type a command (empty line to quit).")
    while True:
        try:
            text = input("> ")
        except EOFError:
            break
        if not text.strip():
            break
        codes, info = lm.predict(text)
        print("  %s   (%.1f ms%s)" % (codes, info["ms"], "" if info["valid"] else ", model output invalid: " + repr(info["raw"])))


if __name__ == "__main__":
    _main()
